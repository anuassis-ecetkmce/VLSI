`ifndef CFS_BRIDGE_TEST_PKG_SV
	`define CFS_BRIDGE_TEST_PKG_SV
	
	`include "uvm_macros.svh"
	`include "cfs_bridge_pkg.sv"
	`include "axi_pkg.sv"
	
	package cfs_bridge_test_pkg;
		import uvm_pkg::*;
		import cfs_bridge_pkg::*;
		import cfs_apb_pkg::*;
		import axi_pkg::*;
		import axi_types_pkg::*;

		`include "axi_sequence_rw.sv"
		`include "axi_write_sequence.sv"
		`include "axi_random_read_seq.sv"

		`include "cfs_bridge_virtual_sequence.sv"

		`include "cfs_bridge_test_base.sv"
		`include "cfs_bridge_test_reg_access.sv"

		
	endpackage

`endif // CFS_BRIDGE_TEST_PKG_SV
